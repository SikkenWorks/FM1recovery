# Read-only Windows device properties, as exposed by Device Manager.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$notes = New-Object System.Collections.Generic.List[string]
$inventory = Get-FM1WindowsInventory
foreach ($note in $inventory.Notes) { $notes.Add([string]$note) }
$disks = @($inventory.Disks | Where-Object {
    $identity = ([string]$_.Model) + ' ' + ([string]$_.PNPDeviceID) + ' ' + ($_.HardwareIds -join ' ')
    $usb = $_.InterfaceType -eq 'USB' -or $_.PNPDeviceID -like 'USBSTOR\*' -or [string]$_.BusType -in @('USB','7') -or $_.UsbAncestor -like 'USB\VID_*'
    $usb -and $identity -match 'WL82' -and $identity -match 'UBOOT'
})
function Read-Property([string]$id, [string]$key) {
    if (-not (Get-Command Get-PnpDeviceProperty -ErrorAction SilentlyContinue)) { return $null }
    try { return (Get-PnpDeviceProperty -InstanceId $id -KeyName $key -ErrorAction Stop).Data }
    catch { return $null }
}
function Describe([string]$id, [string]$name, [string]$disk, [string]$status, [string]$code) {
    $hw = @(Read-Property $id 'DEVPKEY_Device_HardwareIds' | Where-Object { $_ })
    $parent = [string](Read-Property $id 'DEVPKEY_Device_Parent')
    $ancestor = $parent
    $usb = ''
    if ($id -match 'VID_4C4A&PID_8057') { $usb = $id }
    for ($i = 0; $i -lt 6 -and $ancestor; $i++) {
        if ($ancestor -match 'VID_4C4A&PID_8057') { $usb = $ancestor; break }
        $next = [string](Read-Property $ancestor 'DEVPKEY_Device_Parent')
        if ($next -eq $ancestor) { break }; $ancestor = $next
    }
    if (-not $code) { $code = [string](Read-Property $id 'DEVPKEY_Device_ProblemCode') }
    return [pscustomobject]@{ Name=$name; InstanceId=$id; HardwareIds=@($hw); Parent=$parent; UsbId=$usb; DiskNumber=$disk; Status=$status; ProblemCode=$code }
}
$records = @()
foreach ($d in $disks) {
    $records += Describe ([string]$d.PNPDeviceID) ([string]$d.Model) ([string]$d.Index) ([string]$d.Status) ([string]$d.ConfigManagerErrorCode)
}
# Includes a present WL82 with a disk-driver problem, even if Win32_DiskDrive missed it.
if ($records.Count -eq 0) {
    try {
        $present = @(Get-PnpDevice -PresentOnly -ErrorAction Stop | Where-Object { $_.InstanceId -match 'VID_4C4A&PID_8057' -or $_.FriendlyName -match 'WL82.*UBOOT' })
        foreach ($d in $present) { $records += Describe ([string]$d.InstanceId) ([string]$d.FriendlyName) '' ([string]$d.Status) ([string]$d.Problem) }
    } catch { $notes.Add('Present-device query failed: ' + $_.Exception.Message) }
}
[pscustomobject]@{ Devices=@($records); Notes=@($notes) } | ConvertTo-Json -Depth 6 -Compress
