"""GUI adapter for FM1 recovery with read-only Windows discovery."""
import hashlib, json, os, sys, subprocess, base64, re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'/'unbricker'))
import fm1_unbrick as core
FW_SHA='db1642b2b6fa5c2cccb11ffd13878068bb28601678d3644049f99dc40e7edb8a'
def verify():
    p=ROOT/'FM-1.fwsc'
    if hashlib.sha256(p.read_bytes()).hexdigest()!=FW_SHA:
        raise RuntimeError('Embedded V15 firmware failed SHA-256 verification. No device opened.')
    core.verify_jlub(ROOT/'vendor'/'unbricker'/'jl-uboot-tool')
    return p

def emit_detail(key,value):
    value='' if value is None else str(value)
    print('@@DETAIL\t'+key+'\t'+base64.b64encode(value.encode('utf-8')).decode('ascii'),flush=True)

def choose_details(data,path=''):
    records=data.get('Devices') or []
    if isinstance(records,dict):records=[records]
    if path:
        if not core.WIN_PATH_RE.fullmatch(path):raise ValueError('Invalid Windows disk path')
        number=re.search(r'(\d+)$',path).group(1)
        records=[r for r in records if str(r.get('DiskNumber',''))==str(int(number))]
    if len(records)!=1:
        emit_detail('status',str(len(records))+' matching Windows device records. Select a detected device or use manual entry.')
        print('Windows details: '+str(len(records))+' matching records. '+
              ('Select one detected FM1 and read its details again.' if records else 'No matching present device properties were found.'),flush=True)
        return False
    r=records[0]
    hw=r.get('HardwareIds') or []
    if isinstance(hw,str):hw=[hw]
    emit_detail('name',r.get('Name'))
    emit_detail('hardware','\r\n'.join(map(str,hw)))
    emit_detail('parent',r.get('UsbId') or r.get('Parent') or r.get('InstanceId'))
    emit_detail('disk',r.get('DiskNumber'))
    emit_detail('status','Windows status: '+str(r.get('Status') or 'unknown')+
                '; problem code: '+str(r.get('ProblemCode') or 'not reported'))
    print('Windows instance ID: '+str(r.get('InstanceId') or ''),flush=True)
    print('Windows immediate parent: '+str(r.get('Parent') or ''),flush=True)
    print('Windows device properties loaded automatically. Missing fields can be filled manually.',flush=True)
    return True

def read_windows_details(path=''):
    # EncodedCommand uses UTF-16LE as specified by Windows PowerShell.
    # No user-supplied text is interpolated into the PowerShell program.
    script=(ROOT/'vendor'/'unbricker'/'windows_inventory.ps1').read_text(encoding='utf-8')+'\n'+(ROOT/'windows_details.ps1').read_text(encoding='utf-8')
    encoded=base64.b64encode(script.encode('utf-16le')).decode('ascii')
    res=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded],
                       capture_output=True,encoding='utf-8',errors='replace',timeout=45)
    if res.returncode:raise RuntimeError('Windows property query failed: '+res.stderr.strip())
    data=json.loads(res.stdout.lstrip('\ufeff').strip())
    for note in data.get('Notes') or []:print('Windows details: '+str(note),flush=True)
    records=data.get('Devices') or []
    if isinstance(records,dict):records=[records]
    if records and not any(str(r.get('DiskNumber') or '') for r in records):
        print('Windows sees a recovery interface but has not exposed a matching physical disk. Reconnect in OCT-minus mode, wait for Windows to finish installing the device, then click Find FM1. Save this report if it still fails.',flush=True)
    return choose_details(data,path)

def main(argv):
    fw=verify()
    action=argv[0] if argv else 'scan'
    if action=='verify':print('Embedded firmware and pinned WL82 loader verified.');return 0
    if action=='details':
        read_windows_details(argv[1] if len(argv)>1 else '')
        return 0
    if action=='scan':
        devices=core.find_devices()
        for d in devices:print('@@DEVICE\t'+d['path']+'\t'+d['description'],flush=True)
        print('@@COUNT\t'+str(len(devices)),flush=True)
        if not devices:print('FM1 not found. Open Device help and follow the OCT-minus steps.',flush=True)
        try:read_windows_details(devices[0]['path'] if len(devices)==1 else '')
        except Exception as e:print('Automatic device details unavailable: '+str(e)+'. Use Device help to retry or enter them manually.',flush=True)
        return 0
    args=['restore',str(fw),'--verify-v15','--yes','--jl-dir',str(ROOT/'vendor'/'unbricker'/'jl-uboot-tool')]
    if action=='simulate':args+=['--dry-run']
    elif action=='restore':
        # GUI sends an actual scan result, not a path guessed from pasted IDs.
        path=argv[1] if len(argv)>1 else ''
        devices=core.find_devices()
        core.select_device(path,devices)
        if not path:raise RuntimeError('A detected FM1 must be selected before restoring.')
        args+=['--device',path]
    else:raise RuntimeError('Unknown operation')
    return core.main(args)
if __name__=='__main__':
    try:rc=main(sys.argv[1:])
    except Exception as e:print('ERROR: '+str(e),flush=True);rc=1
    raise SystemExit(rc)
